# Plate growth (practice project)

Synthetic practice data for the git exercise.

- `data/raw/plates.csv`: optical density (OD600) of 12 plates,
  3 conditions (control, glucose, salt), read every 2 hours.
  Raw data: never edit.
- `clean.py`: removes excluded plates and writes
  `results/summary.csv` with the mean OD600 at 8 h per condition.
- `notes/`: lab notes.

Run: `python3 clean.py` (or `python clean.py` on Windows).
