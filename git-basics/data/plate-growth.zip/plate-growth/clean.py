"""Remove excluded plates and summarise OD600 at 8 h per condition."""
import csv
from statistics import mean

EXCLUDE = {"P07"}          # contaminated, see notes/2026-11-20.md
FINAL_HOUR = 8

with open("data/raw/plates.csv", newline="") as f:
    rows = [r for r in csv.DictReader(f) if r["plate"] not in EXCLUDE]

by_condition = {}
for r in rows:
    if int(r["hour"]) == FINAL_HOUR:
        by_condition.setdefault(r["condition"], []).append(float(r["od600"]))

with open("results/summary.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["condition", "n_plates", "mean_od600_8h"])
    for cond in sorted(by_condition):
        values = by_condition[cond]
        w.writerow([cond, len(values), round(mean(values), 3)])
print("Wrote results/summary.csv")
