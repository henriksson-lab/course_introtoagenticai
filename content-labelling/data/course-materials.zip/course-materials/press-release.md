# New course brings cell biology to first-year engineers

From this autumn, first-year engineering students can take BIO-1042 Cell biology,
a new course that links lab work with modelling. "Engineers will meet biology in
every field," says the course leader. The course is part of the department's plan
to strengthen interdisciplinary teaching.

(Draft. To be published on the department's news page by the communications office.)
