# BIO-1042 Cell biology (7.5 credits)

This course introduces the structure and function of eukaryotic cells: membranes,
organelles, the cytoskeleton and the cell cycle. Teaching combines lectures, two
laboratory sessions and a written exam.

Schedule: weeks 36 to 43. Course leader: Dr A. Example.

![Overview of an animal cell](fig-cell-overview.png)

![Growth curves from the lab sessions](fig-growth-curves.png)

Questions about the course? Try the course chat assistant at the bottom of this page.
