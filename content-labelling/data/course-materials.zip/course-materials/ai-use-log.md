# Log of AI use: BIO-1042 Cell biology, autumn term

| Date | Item | Tool | What the AI did | Human review |
|---|---|---|---|---|
| 2026-08-18 | course-page.md | Claude Code | Drafted the course description from my old syllabus | I rewrote about half, checked all dates and rules |
| 2026-08-19 | fig-cell-overview.png | ChatGPT (image generation) | Generated a cartoon overview of an animal cell | I checked the organelle labels; two were wrong and I fixed them in an editor |
| 2026-08-20 | fig-growth-curves.png | Claude Code | Wrote an R script that plots our own lab's growth data | I ran the script myself and checked three points by hand |
| 2026-08-22 | press-release.md | ChatGPT | Drafted a news item about the new course for the department web site | Not yet reviewed; the communications office will publish it |
| 2026-08-25 | photo-lab-opening.jpg | An image editor's AI "generative fill" | Removed a colleague who asked not to be shown, and filled in the background; added two students to make the room look busier | None |
| 2026-08-27 | intro-video.mp4 | AI voice tool | Read my script aloud in a synthetic copy of my own voice | I listened to it once |
| 2026-08-28 | faq-bot | Codex | Built a small chat page that answers questions about the course, using a model through an API | I tested ten questions |
