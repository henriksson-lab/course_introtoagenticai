function Y = blcorr(X, bl)
% subtract mean of blank wells, per time point
b = mean(X(:,bl), 2);
Y = X - repmat(b, 1, size(X,2));
Y(Y < 0.001) = 0.001;     % no neg. values (log!)
