growth rates
------------
run gr_calc in matlab (change fname first). needs blcorr, mvavg, fitwin.
output in gr_out_*.txt
thresholds changed in may, see notebook 3 p. 41
/JK
