function S = mvavg(Y, w)
% moving average over w points (centred), shorter at the ends
n = size(Y,1);
h = floor(w/2);
S = Y;
for i = 1:n
    a = max(1, i-h); b = min(n, i+h);
    S(i,:) = mean(Y(a:b,:), 1);
end
