function [mu, r2, a, b] = fitwin(t, y, th1, th2)
% fit log(y) = c + mu*t between first point > th1 and first point > th2
a = find(y > th1, 1);
b = find(y > th2, 1);
if isempty(a) || isempty(b) || b - a < 3
    mu = NaN; r2 = NaN; a = 0; b = 0;
    return
end
tt = t(a:b); ly = log(y(a:b));
p = polyfit(tt, ly, 1);
mu = p(1);
yh = polyval(p, tt);
r2 = 1 - sum((ly-yh).^2) / sum((ly-mean(ly)).^2);
