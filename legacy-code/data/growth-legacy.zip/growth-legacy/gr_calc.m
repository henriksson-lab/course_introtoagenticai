% gr_calc.m
% growth rates from plate reader (Tecan) data
% JK 2016-03, changed 2016-05 (new thresholds), 2017-01 (smoothing)
%
% usage: set fname below and run.  output -> gr_out_XXXX.txt
%
clear all; close all;

fname = 'plate_0312.csv';

d = csvread(fname, 1, 0);      % skip header line
n = size(d,1);
t = (0:n-1)' * 15/60;          % time in h
X = d(:, 2:end);               % 24 wells A1..D6 (row by row)

% blanks are col 1 (A1 B1 C1 D1)
bl = [1 7 13];
Y = blcorr(X, bl);

% smoothing (added 2017, Lars said the curves were too noisy)
Ys = mvavg(Y, 3);

th1 = 0.02;   % start of exp phase
th2 = 0.2;    % end
%th1 = 0.05; th2 = 0.3;   % old values

wn = cell(24,1);
r = 'ABCD';
for k = 1:24
    wn{k} = sprintf('%c%d', r(ceil(k/6)), mod(k-1,6)+1);
end

mu = zeros(24,1); td = mu; r2 = mu; i1 = mu; i2 = mu;
for k = 1:24
    if any(bl == k)
        mu(k) = NaN; td(k) = NaN; r2(k) = NaN;
        continue
    end
    [mu(k), r2(k), i1(k), i2(k)] = fitwin(t, Ys(:,k), th1, th2);
    td(k) = 0.6931 / mu(k) * 60;     % doubling time (min)
end

% strains: col 2-6, rows = replicates
sn = {'WT', 'dA', 'dB', 'dC', 'dAB'};

fo = ['gr_out_' fname(7:10) '.txt'];
f = fopen(fo, 'w');
fprintf(f, 'well\tmu_per_h\ttd_min\tr2\tfirst\tlast\n');
for k = 1:24
    if any(bl == k), continue, end
    fprintf(f, '%s\t%.4f\t%.2f\t%.4f\t%d\t%d\n', wn{k}, mu(k), td(k), r2(k), i1(k), i2(k));
end
fprintf(f, '\n');
fprintf(f, 'strain\tmean_mu\tsd_mu\tn\n');
for s = 1:5
    kk = (0:3)*6 + s + 1;          % wells of this strain
    m = mu(kk); m = m(~isnan(m));
    fprintf(f, '%s\t%.4f\t%.4f\t%d\n', sn{s}, mean(m), std(m), length(m));
end
fclose(f);

%figure; semilogy(t, Ys(:,2:6)); legend(sn)
%print -dpng gr_plot.png
disp(['wrote ' fo])
