# Plant growth under three fertiliser levels

A small greenhouse trial (spring 2026). Does nitrogen fertiliser change how
fast young bean plants grow?

## Data

`data/raw/growth.csv`: one row per plant per week.

| Column | Meaning |
|---|---|
| plant_id | C01-C08 control, L01-L08 low N, H01-H08 high N |
| treatment | control, low_N or high_N |
| week | 0 to 6 |
| height_cm | plant height in cm, soil surface to top leaf |

## How to make the figure

Run `python scripts/make_figure.py`. The figure is saved in `results/`.

## Results

Mean height per treatment and week: `results/growth_plot.png`.
