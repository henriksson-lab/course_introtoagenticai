# Notes for the coding agent

- Raw data is in data/raw/. Never change it.
- Scripts go in scripts/.
- Figures and tables go in output/.
- Use Python with matplotlib only.
