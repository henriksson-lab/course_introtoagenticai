# plot_growth.py: mean plant height per treatment and week
import csv
from collections import defaultdict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

DATA = "C:/Users/anna.k/Desktop/greenhouse/growth.csv"

heights = defaultdict(list)
with open(DATA) as f:
    for row in csv.DictReader(f):
        heights[(row["treatment"], int(row["week"]))].append(float(row["ht"]))

fig, ax = plt.subplots(figsize=(6, 4), dpi=120)
for name, colour in [("control", "#888888"), ("low_N", "#2a7f8f"), ("high_N", "#6b4fa0")]:
    weeks = sorted(w for (t, w) in heights if t == name)
    means = [sum(heights[(name, w)]) / len(heights[(name, w)]) for w in weeks]
    ax.plot(weeks, means, marker="o", color=colour, label=name)
ax.set_xlabel("Week")
ax.set_ylabel("Mean height (cm)")
ax.set_title("Plant height by treatment (n = 8 per group)")
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig("results/growth_plot.png")
