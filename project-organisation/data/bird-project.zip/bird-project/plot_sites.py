# plot_sites.py - total birds per site as a bar chart
# reads counts_clean.csv, writes fig_sites.svg (no extra packages needed)
import csv

totals = {}
with open("counts_clean.csv") as f:
    for r in csv.DictReader(f):
        totals[r["site"]] = totals.get(r["site"], 0) + int(r["count"])

sites = sorted(totals)
top = max(totals.values())
bars = []
for i, s in enumerate(sites):
    h = 300 * totals[s] / top
    x = 80 + i * 90
    bars.append(f'<rect x="{x}" y="{350 - h:.1f}" width="60" height="{h:.1f}" fill="#2a7f8f"/>'
                f'<text x="{x + 30}" y="375" text-anchor="middle">{s}</text>'
                f'<text x="{x + 30}" y="{340 - h:.1f}" text-anchor="middle">{totals[s]}</text>')
svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 420" '
       'font-family="Helvetica, Arial, sans-serif" font-size="16">'
       '<rect width="640" height="420" fill="white"/>'
       '<text x="320" y="30" text-anchor="middle" font-size="20">Birds counted per site, 2025</text>'
       + "".join(bars) +
       '<line x1="70" y1="350" x2="620" y2="350" stroke="black"/>'
       '<text x="320" y="405" text-anchor="middle">site</text></svg>')
with open("fig_sites.svg", "w") as f:
    f.write(svg)
print("wrote fig_sites.svg:", totals)
