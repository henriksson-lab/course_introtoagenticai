# clean.py - combine and clean the raw bird counts
# reads counts_raw_spring.csv and counts_raw_autumn.csv, writes counts_clean.csv
import csv

rows = []
for season, fname in [("spring", "counts_raw_spring.csv"),
                      ("autumn", "counts_raw_autumn.csv")]:
    with open(fname) as f:
        for r in csv.DictReader(f):
            if r["count"] == "":          # blank = site not visited that day
                continue
            rows.append({"date": r["date"], "site": r["site"], "season": season,
                         "species": r["species"],
                         "count": int(r["count"])})

with open("counts_clean.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["date", "site", "season", "species", "count"])
    w.writeheader()
    w.writerows(rows)
print("wrote counts_clean.csv:", len(rows), "rows,",
      sum(r["count"] for r in rows), "birds")
