# Methods (draft)

Volunteers counted birds at six sites in and around the city on two
mornings in spring and two in autumn 2025, using a 10-minute point count.
Site F was excluded in autumn because of flooding.

TODO: say how many volunteers, cite the point-count protocol.
