# Week 3: Enzyme kinetics

*Course page draft for BIO-203, Biochemistry for engineers. Not yet published.*

## Why rates matter

Every enzyme assay in this course ends with a curve: reaction rate against
substrate concentration. This week you learn to read that curve and to fit
the two numbers that describe it, Vmax and Km.

## The model

In biochemistry, Michaelis–Menten kinetics, named after Leonor Michaelis and
Maud Menten, is the simplest case of enzyme kinetics, applied to
enzyme-catalysed reactions involving the transformation of one substrate into
one product. In 1913, Michaelis and Menten expanded on Victor Henri's
fundamental equation of enzyme kinetics, which was established in 1902.

The rate v depends on the substrate concentration S as
v = Vmax * S / (Km + S). At low S the rate rises almost in proportion to S; at
high S it levels off at Vmax. Km is the concentration at which the rate is half
of Vmax, as Michaelis and Menten (1913) showed for invertase.

## This week's data

Figure 1 shows rates measured by last year's lab groups (synthetic data for
this page). The script `fit_mm.py` fits the curve and prints Vmax and Km.

![Figure 1: rate against substrate concentration with the fitted curve](figures/fig1-rates.png)

Figure 2 shows the same kind of data as a double-reciprocal plot, which is
how the constants were estimated before computers.

![Figure 2](figures/fig2-redrawn.png)

![](figures/enzyme-cartoon.png)

## Exercises

1. Read Vmax and Km off Figure 1 by eye. Compare with the fitted values.
2. Why does the double-reciprocal plot exaggerate errors at low S?
