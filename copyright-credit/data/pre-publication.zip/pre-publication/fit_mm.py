# fit_mm.py - fit the Michaelis-Menten model to rate data
#
# Copyright (C) 2018 Example Enzyme Lab, University of Nowhere
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation, either version 3 of the License, or (at your option)
# any later version.

import numpy as np
from scipy.optimize import curve_fit


def michaelis_menten(s, vmax, km):
    return vmax * s / (km + s)


def fit(s, v):
    """Return (vmax, km) fitted by non-linear least squares."""
    (vmax, km), _ = curve_fit(michaelis_menten, s, v, p0=[max(v), np.median(s)])
    return vmax, km


if __name__ == "__main__":
    data = np.loadtxt("rates.csv", delimiter=",", skiprows=1)
    vmax, km = fit(data[:, 0], data[:, 1])
    print(f"Vmax = {vmax:.2f} umol/min, Km = {km:.2f} mM")
