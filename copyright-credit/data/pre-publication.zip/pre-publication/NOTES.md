# My notes (not for the page)

- Section "The model": the agent drafted it, I edited a bit. Check wording?
- Figure 2: asked the agent to redraw Fig. 3 of Lindqvist et al. 2019
  (journal article, not open access) with our own colours.
- Enzyme cartoon: found it online last year for my slides, can't remember
  where. Looks nice.
- Remember to cite Michaelis & Menten properly.
