# Enzyme kinetics course page (BIO-203, week 3)

## Goal
A public course page for week 3, with one figure, a fitting script and two
exercises. To be published on the course website next week.

## Licences I plan to use
- Text and figures: CC BY 4.0
- Code: MIT

## Log of AI use
- 2026-10-02, Claude Code (Pro): wrote fit_mm.py and made figures/fig1-rates.png
  from the synthetic data. I checked the fit against a hand calculation.
- 2026-10-03, Claude Code (Pro): redrew figure 2 from the PDF of the paper.
